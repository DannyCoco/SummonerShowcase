const express = require('express');
const app = express();
const axios = require('axios');
const path = require('path');
const port = 8080;
const API_key = 'RGAPI-1ebbb581-8911-48f7-b68b-feaa02048bc5';
let puuid;
let matchList;
let matchStats = [];
let profilePic;

// Set 'ejs' as the view engine
app.set('view engine', 'ejs');

// Specify the directory where your EJS templates are located
app.set('views', path.join(__dirname, 'views'));

// Serve static files (e.g., CSS) from the 'styles' directory
app.use(express.static('styles'));

// Index page
app.get('/', (req, res) => {
    res.render('index', { errorMessage: "" });
});

app.get('/index', (req, res) => {
    res.render('index', { errorMessage: "" });
});

app.get('/summoner', (req, res) => {
    let displayName = req.query.summonerName;
    if (!displayName) {
        return res.render('index', { errorMessage: "This summoner name does not exist. Please try again." });
    }
    let summonerName = encodeURIComponent(displayName);
    const puuidUrl = `https://na1.api.riotgames.com/lol/summoner/v4/summoners/by-name/${summonerName}?api_key=${API_key}`;

    axios.get(puuidUrl)
        // Gets puuid
        .then(response => {
            puuid = response.data.puuid;
            profilePic = response.data.profileIconId;
            const matchListUrl = `https://americas.api.riotgames.com/lol/match/v5/matches/by-puuid/${puuid}/ids?start=0&count=20&api_key=${API_key}`;

            return axios.get(matchListUrl);
        })
        // Gets list of recent matches
        .then(response2 => {
            matchList = response2.data;
            let matchDetailUrl = `https://americas.api.riotgames.com/lol/match/v5/matches/${matchList[0]}?api_key=${API_key}`;
            //res.render('summoner', { displayName: displayName, data: matchList, profilePic: profilePic });
            return axios.get(matchDetailUrl);
        })

        .then(match1 => {
            let playerStats = match1.data.info.participants;
            let index = playerStats.findIndex(entry => entry.puuid === puuid);
            let myStats = {
                assists: playerStats[index].assists,
                kills: playerStats[index].kills,
                deaths: playerStats[index].deaths,
                kda: playerStats[index].challenges.kda.toFixed(2),
                win: playerStats[index].win,
                summonerName: playerStats[index].summonerName,
                length: match1.data.info.gameDuration
            };
            matchStats.push(myStats);
            let matchDetailUrl = `https://americas.api.riotgames.com/lol/match/v5/matches/${matchList[1]}?api_key=${API_key}`;
            return axios.get(matchDetailUrl);
            //res.render('summoner', { displayName: displayName, data: matchStats, profilePic: profilePic });
        })
        .then(match2 => {
            let playerStats = match2.data.info.participants;
            let index = playerStats.findIndex(entry => entry.puuid === puuid);
            let myStats = {
                assists: playerStats[index].assists,
                kills: playerStats[index].kills,
                deaths: playerStats[index].deaths,
                kda: playerStats[index].challenges.kda.toFixed(2),
                win: playerStats[index].win,
                length: match2.data.info.gameDuration,
                summonerName: playerStats[index].summonerName
            };
            matchStats.push(myStats);
            let matchDetailUrl = `https://americas.api.riotgames.com/lol/match/v5/matches/${matchList[2]}?api_key=${API_key}`;
            //return axios.get(matchDetailUrl);
            res.render('summoner', { displayName: displayName, data: matchStats, profilePic: profilePic });
        }) 
        /*.then(match3 => {
            let playerStats = match3.data.info.participants;
            let index = playerStats.findIndex(entry => entry.puuid === puuid);
            let myStats = {
                assists: playerStats[index].assists,
                kills: playerStats[index].kills,
                deaths: playerStats[index].deaths,
                kda: playerStats[index].challenges.kda.toFixed(2),
                win: playerStats[index].win,
                length: match1.data.info.gameDuration,
                summonerName: playerStats[index].summonerName
            };
            matchStats.push(myStats);
            let matchDetailUrl = `https://americas.api.riotgames.com/lol/match/v5/matches/${matchList[3]}?api_key=${API_key}`;
            return axios.get(matchDetailUrl);
            //res.render('summoner', { displayName: displayName, data: myStats });
        }) */
        /*.then(match4 => {
            let playerStats = match4.data.info.participants;
            let index = playerStats.findIndex(entry => entry.puuid === puuid);
            let myStats = {
                assists: playerStats[index].assists,
                kills: playerStats[index].kills,
                deaths: playerStats[index].deaths,
                kda: playerStats[index].challenges.kda.toFixed(2),
                win: playerStats[index].win,
                length: match1.data.info.gameDuration,
                summonerName: playerStats[index].summonerName
            };
            matchStats.push(myStats);
            let matchDetailUrl = `https://americas.api.riotgames.com/lol/match/v5/matches/${matchList[4]}?api_key=${API_key}`;
            return axios.get(matchDetailUrl);
            //res.render('summoner', { displayName: displayName, data: myStats });
         })*/

        // Gets match details
        /*.then(match5 => {
            let playerStats = match5.data.info.participants;
            let index = playerStats.findIndex(entry => entry.puuid === puuid);
            let myStats = {
                assists: playerStats[index].assists,
                kills: playerStats[index].kills,
                deaths: playerStats[index].deaths,
                kda: playerStats[index].challenges.kda.toFixed(2),
                win: playerStats[index].win,
                length: match1.data.info.gameDuration,
                summonerName: playerStats[index].summonerName
            };
            matchStats.push(myStats);
            res.render('summoner', { displayName: displayName, data: matchStats, profilePic: profilePic });
        }) */
        // Handles errors
        .catch(error => {
            res.render('index', { errorMessage: "This summoner name does not exist. Please tr3y again." });
        });
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
