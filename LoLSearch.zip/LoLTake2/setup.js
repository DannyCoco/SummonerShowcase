const riotKey = 'api_key=RGAPI-eb1b2ad7-aa5f-4b57-9c4b-43b5fc39bdbc';
const sp = '%20';

function updateSummonerName() {
    var urlParams = new URLSearchParams(window.location.search);
    var sumName = urlParams.get("summonerName");
    document.getElementById("summonerName").textContent = sumName;
}

async function sumByName(name) {
    const response = await fetch(`http://localhost:3000/summoner?summonerName=${name}`);
    const data = await response.json();
    return data;
}