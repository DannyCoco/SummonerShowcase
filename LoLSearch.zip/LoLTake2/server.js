import express from 'express';
import fetch from 'node-fetch';
const app = express();
const port = 3000;

app.get('/summoner', async (req, res) => {
    const summonerName = req.query.summonerName;
    const riotKey = 'RGAPI-eb1b2ad7-aa5f-4b57-9c4b-43b5fc39bdbc';
    const url = `https://na1.api.riotgames.com/lol/summoner/v4/summoners/by-name/${summonerName}?api_key=${riotKey}`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        res.send(data);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('An error occurred while fetching data from the Riot Games API.');
    }
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});